# Welcome to Chainlit! 🚀🤖

Hi, This is a simple Chainlit app to have chat with your documents.

## Useful Links 🔗

**Youtube Playlist**  
Get started with [Chainlit Playlist](https://youtube.com/playlist?list=PLz-qytj7eIWWNnbCRxflmRbYI02jZeG0k) 🎥  
Get started with [LangChain Playlist](https://youtube.com/playlist?list=PLz-qytj7eIWVd1a5SsQ1dzOjVDHdgC1Ck) 🎥  

Happy coding! 💻😊

## If you want to support
- [Buy me a coffee](https://ko-fi.com/datasciencebasics) && [Patreon](https://www.patreon.com/datasciencebasics)

